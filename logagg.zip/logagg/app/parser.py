import glob
import hashlib
import os
import re
from datetime import datetime, timezone

from sqlalchemy.dialects.mysql import insert

from .db import LogEntry, get_session

# Форматы Common и Combined (Combined = Common + referer + user-agent)
LINE_RE = re.compile(
    r'^(?P<ip>\S+) (?P<ident>\S+) (?P<user>\S+) \[(?P<time>[^\]]+)\] '
    r'"(?P<method>\S+) (?P<url>.*?) (?P<protocol>[^\s"]+)" '
    r'(?P<status>\d{3}) (?P<size>\d+|-)'
    r'(?: "(?P<referer>[^"]*)" "(?P<agent>[^"]*)")?\s*$'
)
MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def _parse_time(s):
    # 10/May/2026:13:55:36 +0000 (месяц разбираем сами, чтобы не зависеть от локали)
    d, mon, rest = s.split("/", 2)
    dt = datetime.strptime(f"{d}/{MONTHS[mon]:02d}/{rest}", "%d/%m/%Y:%H:%M:%S %z")
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def parse_line(line):
    """Возвращает dict для LogEntry или бросает ValueError."""
    m = LINE_RE.match(line.strip())
    if not m:
        raise ValueError("строка не соответствует формату Common/Combined")
    try:
        t = _parse_time(m["time"])
    except (ValueError, KeyError):
        raise ValueError(f"неверная дата/время: {m['time']}")
    dash = lambda v: None if v in (None, "-") else v
    return dict(ip=m["ip"], user=dash(m["user"]), time=t, method=m["method"],
                url=m["url"], protocol=m["protocol"], status=int(m["status"]),
                size=0 if m["size"] == "-" else int(m["size"]),
                referer=dash(m["referer"]), user_agent=dash(m["agent"]),
                line_hash=hashlib.sha1(line.strip().encode("utf-8", "replace")).hexdigest())


def _flush(session, batch):
    if batch:
        # INSERT IGNORE: строки, которые уже есть в БД (по хешу), пропускаются
        res = session.execute(insert(LogEntry).prefix_with("IGNORE"), batch)
        session.commit()
        return res.rowcount
    return 0


def parse_logs(cfg):
    """Разбирает все файлы по маске. Возвращает статистику."""
    pattern = os.path.join(cfg["logs"]["dir"], cfg["logs"]["mask"])
    files = sorted(glob.glob(pattern))
    stats = {"files": 0, "lines": 0, "inserted": 0, "bad": 0, "errors": []}
    if not files:
        stats["errors"].append(f"Файлы не найдены: {pattern}")
        return stats

    session = get_session()
    try:
        with open(cfg["errors_log"], "a", encoding="utf-8") as elog:
            for path in files:
                try:
                    f = open(path, encoding="utf-8", errors="replace")
                except OSError as e:
                    stats["errors"].append(f"Не удалось открыть {path}: {e.strerror}")
                    continue
                stats["files"] += 1
                batch = []
                with f:
                    for n, line in enumerate(f, 1):
                        if not line.strip():
                            continue
                        stats["lines"] += 1
                        try:
                            batch.append(parse_line(line))
                        except ValueError as e:
                            stats["bad"] += 1
                            elog.write(f"{datetime.now():%F %T} {path}:{n}: {e}: {line.strip()[:200]}\n")
                        if len(batch) >= 500:
                            stats["inserted"] += _flush(session, batch)
                            batch = []
                stats["inserted"] += _flush(session, batch)
    finally:
        session.close()
    return stats
